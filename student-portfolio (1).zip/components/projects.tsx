import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Instagram } from "lucide-react"

const projects = [
  {
    title: "Detailing Business",
    description:
      "Professional car detailing service providing premium quality care for vehicles. Specializing in interior and exterior detailing, paint correction, and ceramic coating applications.",
    tech: ["Customer Service", "Quality Management", "Business Operations", "Marketing"],
    instagram: "https://instagram.com/kevin_bgb",
    featured: true,
  },
  {
    title: "International Economics Studies",
    description:
      "Academic research focusing on global trade patterns, economic development, and Financial Analysis.",
    tech: ["Economic Analysis", "Data Research", "Market Studies"],
    featured: false,
  },
]

export function Projects() {
  return (
    <section id="projects" className="py-24 px-6">
      <div className="container mx-auto max-w-5xl">
        <h2 className="text-sm uppercase tracking-wider text-muted-foreground mb-12">Projects</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {projects.map((project) => (
            <Card key={project.title} className="p-6 flex flex-col">
              <h3 className="text-xl font-medium mb-3 text-foreground">{project.title}</h3>
              <p className="text-muted-foreground mb-4 leading-relaxed flex-grow">{project.description}</p>
              <div className="flex flex-wrap gap-2 mb-4">
                {project.tech.map((tech) => (
                  <span key={tech} className="text-xs px-3 py-1 bg-accent/10 text-accent rounded-full">
                    {tech}
                  </span>
                ))}
              </div>
              {project.instagram && (
                <div className="flex gap-3">
                  <Button variant="outline" size="sm" asChild>
                    <a href={project.instagram} target="_blank" rel="noopener noreferrer">
                      <Instagram className="w-4 h-4 mr-2" />
                      View on Instagram
                    </a>
                  </Button>
                </div>
              )}
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
