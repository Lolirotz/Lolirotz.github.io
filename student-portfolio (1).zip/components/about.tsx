export function About() {
  return (
    <section id="about" className="py-24 px-6">
      <div className="container mx-auto max-w-3xl">
        <h2 className="text-sm uppercase tracking-wider text-muted-foreground mb-8">About</h2>
        <div className="space-y-6 text-lg leading-relaxed">
          <p>
            I'm an International Economic Student with a passion for entrepreneurship and business development. My
            academic journey focuses on understanding global markets, economic systems, and international trade
            dynamics.
          </p>
          <p>
            Currently, I'm running my own detailing business, where I apply economic principles to real-world business
            operations. This hands-on experience has taught me valuable lessons about customer service, quality
            management, and sustainable business growth.
          </p>
          <p>
            I believe in combining theoretical knowledge with practical application, constantly learning and adapting to
            create value in everything I do.
          </p>
        </div>
      </div>
    </section>
  )
}
