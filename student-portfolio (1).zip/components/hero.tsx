export function Hero() {
  return (
    <section id="hero" className="min-h-screen flex items-center justify-center px-6">
      <div className="container mx-auto max-w-4xl text-center">
        <h1 className="text-6xl md:text-7xl font-bold mb-6 text-balance">Kevin Bauer</h1>
        <p className="text-xl md:text-2xl text-muted-foreground mb-8 text-balance">International Economic Student</p>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
          Studying international economics while building a successful detailing business. Passionate about
          entrepreneurship, business development, and creating value through quality service.
        </p>
      </div>
    </section>
  )
}
